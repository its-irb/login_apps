jQuery(function(){$("#all-apps-table").DataTable({stateSave:!0})});
//# sourceMappingURL=/pun/sys/dashboard/assets/apps.js-3d7b8d0161f055ab167f9abe8d11a89d8cffa7d4522e25ab4bb536590452d3c1.map
//!
;
