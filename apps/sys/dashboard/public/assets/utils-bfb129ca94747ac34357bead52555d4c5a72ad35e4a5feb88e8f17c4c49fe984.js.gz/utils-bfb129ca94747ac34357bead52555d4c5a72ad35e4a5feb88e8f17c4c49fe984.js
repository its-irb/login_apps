function r(e){switch(e){case"completed":return"badge-success";case"running":return"badge-primary";case"queued":return"badge-info";case"queued_held":return"badge-warning";case"suspended":return"badge-warning";default:return"badge-warning"}}function a(e){return e.charAt(0).toUpperCase()+e.slice(1)}export{a as capitalizeFirstLetter,r as cssBadgeForState};
//# sourceMappingURL=/pun/sys/dashboard/assets/utils.js-7f236baa802b5536b4027f37b0133bea4e1a39689e08daa42a6d840cab7ab017.map
//!
;
